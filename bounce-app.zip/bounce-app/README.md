# Bounce

Find a game, fill a spot, or host your own. Pickleball, basketball, futsal, tennis, running, volleyball and more.

## What's inside

- `src/` – the app (React + Vite)
- `supabase/schema.sql` – the database, security rules and live updates. Run it once in the Supabase SQL Editor.
- `public/` – app icons and the home-screen manifest
- `vercel.json` – lets Vercel serve every page of the app

## Settings

Add these in Vercel (Settings → Environment Variables), or in a `.env` file to run locally:

| Name | What it is |
| --- | --- |
| `VITE_SUPABASE_URL` | Supabase Project URL |
| `VITE_SUPABASE_ANON_KEY` | Supabase anon public key |
| `VITE_ENABLE_GOOGLE` | Set to `false` to hide the Google button (shown by default) |
| `VITE_ENABLE_APPLE` | Set to `true` once Sign in with Apple is set up in Supabase |

## Run it on a computer (optional)

```
npm install
npm run dev
```

Follow the Bounce Launch Guide for the full setup.
