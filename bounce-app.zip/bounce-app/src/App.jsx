import { BrowserRouter, Navigate, Route, Routes } from 'react-router-dom';
import { configured } from './supabase.js';
import { AuthProvider } from './auth.jsx';
import { ToastProvider } from './toast.jsx';
import Layout from './components/Layout.jsx';
import Logo from './components/Logo.jsx';
import Discover from './pages/Discover.jsx';
import Game from './pages/Game.jsx';
import Host from './pages/Host.jsx';
import Mine from './pages/Mine.jsx';
import Profile from './pages/Profile.jsx';
import Login from './pages/Login.jsx';

function NotConfigured() {
  return (
    <div className="app">
      <div className="inner gut setup">
        <Logo />
        <h1>Almost there</h1>
        <p>
          Bounce needs its database connection. Add <code>VITE_SUPABASE_URL</code> and{' '}
          <code>VITE_SUPABASE_ANON_KEY</code> to your Vercel environment variables (or a <code>.env</code> file when
          running locally), then redeploy.
        </p>
      </div>
    </div>
  );
}

export default function App() {
  if (!configured) return <NotConfigured />;
  return (
    <AuthProvider>
      <ToastProvider>
        <BrowserRouter>
          <Routes>
            <Route element={<Layout />}>
              <Route index element={<Discover />} />
              <Route path="game/:id" element={<Game />} />
              <Route path="host" element={<Host />} />
              <Route path="mine" element={<Mine />} />
              <Route path="profile" element={<Profile />} />
              <Route path="login" element={<Login />} />
              <Route path="*" element={<Navigate to="/" replace />} />
            </Route>
          </Routes>
        </BrowserRouter>
      </ToastProvider>
    </AuthProvider>
  );
}
