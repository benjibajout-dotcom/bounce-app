import { Link } from 'react-router-dom';
import { SPORT_LABEL } from '../lib/constants.js';
import { fmtTime, gameStart, placeLine, playerCount, priceLabel, shortDow, spotsLeft } from '../lib/format.js';

export default function GameCard({ game }) {
  const start = gameStart(game);
  const count = playerCount(game);
  const left = spotsLeft(game, count);
  const spotsClass = left === 0 ? 'spots full' : left <= 2 ? 'spots low' : 'spots';

  return (
    <Link className="game" to={`/game/${game.id}`}>
      <div className="when">
        <small>{shortDow(start)}</small>
        <b>{fmtTime(start)}</b>
      </div>
      <div className="gbody">
        <div className="sport">
          {SPORT_LABEL[game.sport] ?? game.sport}
          {game.one_short && left > 0 && <span className="tag tag-accent">One short</span>}
        </div>
        <div className="gtitle">{game.title}</div>
        <div className="meta">{placeLine(game)}</div>
      </div>
      <div className="gright">
        <span className={spotsClass}>
          {left === 0 ? 'Full' : `${count}/${game.capacity}`}
          <span className="sr"> going</span>
        </span>
        <span className="price">{priceLabel(game)}</span>
      </div>
    </Link>
  );
}
