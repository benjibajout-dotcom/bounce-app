const base = {
  viewBox: '0 0 24 24',
  fill: 'none',
  stroke: 'currentColor',
  strokeWidth: 2,
  strokeLinecap: 'round',
  strokeLinejoin: 'round',
  'aria-hidden': true,
};

export const SearchIcon = () => (
  <svg {...base}><circle cx="11" cy="11" r="7" /><path d="m20 20-3.5-3.5" /></svg>
);
export const BackIcon = () => (
  <svg {...base}><path d="M15 18l-6-6 6-6" /></svg>
);
export const SendIcon = () => (
  <svg {...base} strokeWidth={2.2}><path d="M5 12h14M13 6l6 6-6 6" /></svg>
);
export const ShareIcon = () => (
  <svg {...base}><path d="M12 3v12M7 8l5-5 5 5M5 14v5a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2v-5" /></svg>
);
export const CompassIcon = () => (
  <svg {...base}><circle cx="12" cy="12" r="9" /><path d="m15.5 8.5-2 5-5 2 2-5z" /></svg>
);
export const CalendarIcon = () => (
  <svg {...base}><rect x="3" y="5" width="18" height="16" rx="2" /><path d="M3 10h18M8 3v4M16 3v4" /></svg>
);
export const PlusIcon = () => (
  <svg {...base} strokeWidth={2.5}><path d="M12 5v14M5 12h14" /></svg>
);
export const PersonIcon = () => (
  <svg {...base}><circle cx="12" cy="8" r="4" /><path d="M4 21c1-4 4.4-6 8-6s7 2 8 6" /></svg>
);
export const CourtArt = () => (
  <svg className="court" viewBox="0 0 190 140" fill="none" stroke="currentColor" strokeWidth="4" aria-hidden="true">
    <rect x="10" y="10" width="170" height="120" rx="3" />
    <path d="M95 10v120" />
    <circle cx="95" cy="70" r="26" />
  </svg>
);
