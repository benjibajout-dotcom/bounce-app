import { useState } from 'react';

const COLORS = ['#FFC79E', '#BFE0D2', '#C9D8FF', '#FFE38A', '#E5D4FF', '#FFD1DC', '#CDEBC0'];

function colorFor(id = '') {
  let h = 0;
  for (let i = 0; i < id.length; i++) h = (h * 31 + id.charCodeAt(i)) >>> 0;
  return COLORS[h % COLORS.length];
}

export function initials(name) {
  const parts = (name || '').trim().split(/\s+/).filter(Boolean);
  if (!parts.length) return '?';
  return (parts[0][0] + (parts[1]?.[0] ?? '')).toUpperCase();
}

// Shows the player's Google/Apple photo when there is one, otherwise their initials.
export default function Avatar({ id, name, src, size = 50 }) {
  const [broken, setBroken] = useState(false);
  const style = { width: size, height: size, fontSize: Math.round(size * 0.36) };
  if (src && !broken) {
    return (
      <img
        className="avatar"
        src={src}
        alt=""
        style={style}
        referrerPolicy="no-referrer"
        onError={() => setBroken(true)}
      />
    );
  }
  return (
    <span className="avatar" aria-hidden="true" style={{ ...style, background: colorFor(id), color: '#0F1F1A' }}>
      {initials(name)}
    </span>
  );
}
