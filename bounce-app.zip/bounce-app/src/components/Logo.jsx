// The Bounce mark: a smiling orange ball mid-bounce, with its trail and shadow.
export function BallMark({ size = 30, trail = true }) {
  return (
    <svg width={size} height={size} viewBox="0 0 64 64" aria-hidden="true" className="ballmark">
      {trail && (
        <g fill="currentColor" opacity="0.4">
          <circle cx="9.2" cy="47" r="1.6" />
          <circle cx="11.4" cy="38.6" r="1.85" />
          <circle cx="14.3" cy="31.4" r="2.1" />
          <circle cx="17.6" cy="25.6" r="2.35" />
          <circle cx="21.2" cy="21.3" r="2.6" />
        </g>
      )}
      <ellipse cx="38" cy="56" rx="11" ry="3" fill="currentColor" opacity="0.16" />
      <circle cx="38" cy="30" r="15" fill="#FF8A3D" />
      <circle cx="31" cy="22" r="2.8" fill="#FFFFFF" opacity="0.5" />
      <ellipse cx="33.6" cy="27.5" rx="1.9" ry="2.4" fill="#1A0E05" />
      <ellipse cx="42.4" cy="27.5" rx="1.9" ry="2.4" fill="#1A0E05" />
      <path d="M32.6 33.2 Q 38 38.4 43.4 33.2" fill="none" stroke="#1A0E05" strokeWidth="2.4" strokeLinecap="round" />
    </svg>
  );
}

export default function Logo() {
  return (
    <span className="logo">
      <BallMark />
      <span className="logo-word">bounce</span>
    </span>
  );
}
