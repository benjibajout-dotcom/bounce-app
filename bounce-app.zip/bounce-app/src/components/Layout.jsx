import { useEffect, useRef } from 'react';
import { Link, NavLink, Outlet, useLocation } from 'react-router-dom';
import { useAuth } from '../auth.jsx';
import Avatar from './Avatar.jsx';
import Logo from './Logo.jsx';
import { CalendarIcon, CompassIcon, PersonIcon, PlusIcon } from './Icons.jsx';

export default function Layout() {
  const { userId, profile } = useAuth();
  const { pathname } = useLocation();
  const mainRef = useRef(null);

  useEffect(() => {
    mainRef.current?.scrollTo({ top: 0 });
  }, [pathname]);
  const needsName = userId && profile && !profile.display_name && pathname !== '/profile';
  const discoverActive = pathname === '/' || pathname.startsWith('/game/');

  return (
    <div className="app">
      <header className="top gut">
        <Link to="/" className="logo-link" aria-label="Bounce home">
          <Logo />
        </Link>
        <div className="top-right">
          {profile?.suburb && <span className="where">{profile.suburb}</span>}
          {userId ? (
            <Link to="/profile" className="me-btn" aria-label="Your profile">
              <Avatar id={userId} name={profile?.display_name} src={profile?.avatar_url} size={36} />
            </Link>
          ) : (
            <Link to="/login" className="btn btn-line btn-sm">Sign in</Link>
          )}
        </div>
      </header>

      <main className="main" ref={mainRef}>
        <div className="inner gut">
          {needsName && (
            <Link to="/profile" className="notice notice-link">
              Add your name so players know who’s coming →
            </Link>
          )}
          <div className="page" key={pathname}>
            <Outlet />
          </div>
        </div>
      </main>

      <nav className="tabs gut" aria-label="Main">
        <Link to="/" className="tab" aria-current={discoverActive ? 'page' : undefined}>
          <CompassIcon />Discover
        </Link>
        <NavLink to="/mine" className="tab">
          <CalendarIcon />My games
        </NavLink>
        <NavLink to="/host" className="tab">
          <span className="plus"><PlusIcon /></span>Host
        </NavLink>
        <NavLink to="/profile" className="tab">
          <PersonIcon />Profile
        </NavLink>
      </nav>
    </div>
  );
}
