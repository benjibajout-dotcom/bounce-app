import { useCallback, useEffect, useState } from 'react';
import { supabase } from './supabase.js';

// Re-runs `load` whenever any of the given tables change (live updates).
export function useLive(channelName, tables, load) {
  useEffect(() => {
    load();
    let channel = supabase.channel(`${channelName}-${Math.random().toString(36).slice(2)}`);
    tables.forEach((table) => {
      channel = channel.on('postgres_changes', { event: '*', schema: 'public', table }, () => load());
    });
    channel.subscribe();
    // Refresh when the app comes back to the foreground.
    const onVisible = () => document.visibilityState === 'visible' && load();
    document.addEventListener('visibilitychange', onVisible);
    return () => {
      document.removeEventListener('visibilitychange', onVisible);
      supabase.removeChannel(channel);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [channelName, load]);
}

// The ids of games the signed-in player is in.
export function useMyGameIds(userId) {
  const [ids, setIds] = useState(new Set());
  const load = useCallback(async () => {
    if (!userId) {
      setIds(new Set());
      return;
    }
    const { data } = await supabase.from('game_players').select('game_id').eq('user_id', userId);
    setIds(new Set((data ?? []).map((r) => r.game_id)));
  }, [userId]);
  useLive(`my-games-${userId ?? 'anon'}`, ['game_players'], load);
  return ids;
}

export function friendlyError(error, fallback) {
  const msg = error?.message ?? '';
  if (msg.includes('GAME_FULL')) return 'That game just filled up.';
  if (msg.includes('GAME_FINISHED')) return 'That game has already finished.';
  if (msg.includes('GAME_NOT_FOUND')) return 'That game isn’t there anymore.';
  if (msg.toLowerCase().includes('network') || msg.toLowerCase().includes('fetch')) {
    return 'You seem to be offline. Check your connection and try again.';
  }
  return fallback;
}
