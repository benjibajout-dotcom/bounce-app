// A short "you're in" moment: the Bounce ball drops in, bounces and bursts into colour.
const BALL =
  '<svg viewBox="0 0 64 64"><circle cx="32" cy="32" r="28" fill="#FF8A3D"/>' +
  '<circle cx="20" cy="17" r="5" fill="#FFFFFF" opacity="0.5"/>' +
  '<ellipse cx="23.5" cy="28" rx="3.6" ry="4.5" fill="#1A0E05"/>' +
  '<ellipse cx="40.5" cy="28" rx="3.6" ry="4.5" fill="#1A0E05"/>' +
  '<path d="M21.5 39 Q 32 49 42.5 39" fill="none" stroke="#1A0E05" stroke-width="4.4" stroke-linecap="round"/></svg>';

const COLORS = ['#FF8A3D', '#1F5C4A', '#FFD23F', '#8FB8FF', '#7FC4A8'];

export function celebrate() {
  if (window.matchMedia?.('(prefers-reduced-motion: reduce)').matches) return;
  const el = document.createElement('div');
  el.className = 'celebrate';
  el.setAttribute('aria-hidden', 'true');
  let dots = '';
  for (let i = 0; i < 16; i++) {
    const angle = (i / 16) * 360 + Math.random() * 12;
    const dist = 70 + Math.random() * 60;
    dots += `<span style="--a:${angle}deg;--d:${dist}px;background:${COLORS[i % COLORS.length]}"></span>`;
  }
  el.innerHTML = `<div class="celebrate-ball">${BALL}</div><div class="burst">${dots}</div>`;
  document.body.appendChild(el);
  setTimeout(() => el.remove(), 1700);
}
