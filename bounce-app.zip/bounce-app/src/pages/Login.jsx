import { useEffect, useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { useAuth } from '../auth.jsx';
import { supabase } from '../supabase.js';
import { BallMark } from '../components/Logo.jsx';

// Sign-in buttons are switched on with environment variables once each
// provider is set up in Supabase (see the setup guide).
const SHOW_GOOGLE = import.meta.env.VITE_ENABLE_GOOGLE !== 'false';
const SHOW_APPLE = import.meta.env.VITE_ENABLE_APPLE === 'true';

function safeNext(value) {
  return value && value.startsWith('/') && !value.startsWith('//') ? value : '/';
}

const GoogleLogo = () => (
  <svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true">
    <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
    <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
    <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l3.66-2.84z" />
    <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" />
  </svg>
);

const AppleLogo = () => (
  <svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true" fill="currentColor">
    <path d="M16.37 12.6c-.02-2.3 1.88-3.4 1.96-3.45-1.07-1.56-2.73-1.78-3.32-1.8-1.41-.14-2.76.83-3.47.83-.72 0-1.82-.81-2.99-.79-1.54.02-2.96.9-3.75 2.27-1.6 2.78-.41 6.89 1.15 9.14.76 1.1 1.67 2.34 2.86 2.3 1.15-.05 1.58-.74 2.97-.74 1.38 0 1.77.74 2.98.72 1.23-.02 2.01-1.12 2.76-2.23.87-1.28 1.23-2.52 1.25-2.58-.03-.01-2.39-.92-2.4-3.67zM14.1 5.86c.63-.77 1.06-1.83.94-2.89-.91.04-2.02.61-2.67 1.37-.58.67-1.1 1.76-.96 2.8 1.02.08 2.06-.52 2.69-1.28z" />
  </svg>
);

export default function Login() {
  const { userId } = useAuth();
  const navigate = useNavigate();
  const [params] = useSearchParams();
  const next = safeNext(params.get('next'));
  const [email, setEmail] = useState('');
  const [code, setCode] = useState('');
  const [step, setStep] = useState('choose'); // choose | code
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (userId) navigate(next, { replace: true });
  }, [userId, next, navigate]);

  async function withProvider(provider) {
    setError('');
    const { error: err } = await supabase.auth.signInWithOAuth({
      provider,
      options: { redirectTo: `${window.location.origin}${next}` },
    });
    if (err) setError('That sign-in option isn’t working right now. Try email instead.');
  }

  async function sendCode(e) {
    e.preventDefault();
    setError('');
    if (!/^\S+@\S+\.\S+$/.test(email.trim())) {
      setError('Enter the email address you use every day.');
      return;
    }
    setBusy(true);
    const { error: err } = await supabase.auth.signInWithOtp({
      email: email.trim(),
      options: { emailRedirectTo: `${window.location.origin}${next}` },
    });
    setBusy(false);
    if (err) setError('Couldn’t send the email. Check the address and try again in a minute.');
    else setStep('code');
  }

  async function verify(e) {
    e.preventDefault();
    setError('');
    setBusy(true);
    const { error: err } = await supabase.auth.verifyOtp({ email: email.trim(), token: code.trim(), type: 'email' });
    setBusy(false);
    if (err) setError('That code didn’t work. Check the latest email, or send a new code.');
  }

  return (
    <section className="login">
      <div className="login-hero">
        <BallMark size={72} />
        <h1>Find a game in minutes</h1>
        <p className="meta">Join pickup games, fill a spot when a team is one short, or host your own.</p>
      </div>

      {step === 'choose' && (
        <>
          <div className="stack">
            {SHOW_APPLE && (
              <button type="button" className="btn btn-apple" onClick={() => withProvider('apple')}>
                <AppleLogo />Continue with Apple
              </button>
            )}
            {SHOW_GOOGLE && (
              <button type="button" className="btn btn-google" onClick={() => withProvider('google')}>
                <GoogleLogo />Continue with Google
              </button>
            )}
          </div>

          {(SHOW_APPLE || SHOW_GOOGLE) && <div className="divider"><span>or use your email</span></div>}

          <form className="stack" onSubmit={sendCode} noValidate>
            <div className="field">
              <label htmlFor="login-email">Email</label>
              <input id="login-email" type="email" inputMode="email" autoComplete="email" placeholder="you@example.com"
                value={email} onChange={(e) => setEmail(e.target.value)} />
            </div>
            <button className="btn btn-brand" type="submit" disabled={busy}>{busy ? 'Sending…' : 'Email me a sign-in code'}</button>
          </form>
        </>
      )}

      {step === 'code' && (
        <form className="stack" onSubmit={verify} noValidate>
          <p>We sent a sign-in email to <b>{email.trim()}</b>. Tap the link in it, or type the 6-digit code here.</p>
          <div className="field">
            <label htmlFor="login-code">Code</label>
            <input id="login-code" inputMode="numeric" autoComplete="one-time-code" maxLength={6} placeholder="123456"
              value={code} onChange={(e) => setCode(e.target.value.replace(/\D/g, ''))} />
          </div>
          <button className="btn btn-brand" type="submit" disabled={busy || code.length < 6}>{busy ? 'Checking…' : 'Sign in'}</button>
          <button type="button" className="btn btn-line" onClick={() => { setStep('choose'); setCode(''); }}>
            Use a different email
          </button>
        </form>
      )}

      {error && <p className="err" role="alert">{error}</p>}

      <p className="foot">By continuing you agree to play fair and be a good sport.</p>
    </section>
  );
}
