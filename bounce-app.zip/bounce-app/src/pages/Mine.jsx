import { useCallback, useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../auth.jsx';
import { supabase } from '../supabase.js';
import { useLive } from '../hooks.js';
import { gameStart, isUpcoming } from '../lib/format.js';
import GameCard from '../components/GameCard.jsx';

export default function Mine() {
  const { userId } = useAuth();
  const [games, setGames] = useState(null);

  const load = useCallback(async () => {
    if (!userId) return;
    const { data } = await supabase
      .from('game_players')
      .select('game:games(*, game_players(count))')
      .eq('user_id', userId);
    setGames((data ?? []).map((r) => r.game).filter(Boolean));
  }, [userId]);
  useLive(`mine-${userId ?? 'anon'}`, ['games', 'game_players'], load);

  const header = (
    <section className="hello">
      <h1>My games</h1>
      <p className="meta">Games you’re hosting or playing in.</p>
    </section>
  );

  if (!userId) {
    return (
      <>
        {header}
        <div className="empty">
          <strong>Sign in to see your games</strong>
          <p>Keep track of everything you’ve joined or hosted.</p>
          <Link className="btn btn-accent" to="/login?next=/mine">Sign in</Link>
        </div>
      </>
    );
  }
  if (games === null) {
    return (
      <>
        {header}
        <div className="list games-grid" aria-label="Loading your games">
          {[0, 1, 2].map((i) => <div key={i} className="skeleton" />)}
        </div>
      </>
    );
  }

  const byStart = (a, b) => gameStart(a) - gameStart(b);
  const hosting = games.filter((g) => isUpcoming(g) && g.host_id === userId).sort(byStart);
  const playing = games.filter((g) => isUpcoming(g) && g.host_id !== userId).sort(byStart);
  const played = games.filter((g) => !isUpcoming(g)).sort(byStart).reverse().slice(0, 20);

  if (!games.length) {
    return (
      <>
        {header}
        <div className="empty">
          <strong>No games yet</strong>
          <p>Join a game near you or host your own.</p>
          <div className="cta center">
            <Link className="btn btn-accent" to="/">Find a game</Link>
            <Link className="btn btn-line" to="/host">Host a game</Link>
          </div>
        </div>
      </>
    );
  }

  const section = (title, list, emptyText) => (
    <section className="list games-grid">
      <div className="list-head group-label-row">
        <h2>{title}</h2>
        <span className="meta">{list.length}</span>
      </div>
      {list.length ? list.map((g) => <GameCard key={g.id} game={g} />) : <p className="meta">{emptyText}</p>}
    </section>
  );

  return (
    <>
      {header}
      {section('Playing', playing, 'You haven’t joined any upcoming games.')}
      {section('Hosting', hosting, 'You’re not hosting anything right now.')}
      {played.length > 0 && section('Played', played, '')}
    </>
  );
}
