import { Fragment, useCallback, useMemo, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../auth.jsx';
import { supabase } from '../supabase.js';
import { useLive, useMyGameIds, friendlyError } from '../hooks.js';
import { useToast } from '../toast.jsx';
import { celebrate } from '../celebrate.js';
import { SPORTS, SPORT_LABEL } from '../lib/constants.js';
import {
  dayKey, dowName, fmtDay, gameStart, isUpcoming, priceLabel, spotsLeft, startsLabel, todayKey,
} from '../lib/format.js';
import GameCard from '../components/GameCard.jsx';
import { SearchIcon } from '../components/Icons.jsx';

export default function Discover() {
  const { userId, profile } = useAuth();
  const toast = useToast();
  const navigate = useNavigate();
  const myIds = useMyGameIds(userId);
  const [games, setGames] = useState(null);
  const [error, setError] = useState('');
  const [sport, setSport] = useState('all');
  const [day, setDay] = useState('all');
  const [q, setQ] = useState('');

  const load = useCallback(async () => {
    const since = new Date(Date.now() - 6 * 3600 * 1000).toISOString();
    const { data, error: err } = await supabase
      .from('games')
      .select('*, game_players(count)')
      .gte('starts_at', since)
      .order('starts_at')
      .limit(300);
    if (err) {
      setError('Couldn’t load games. Pull down or reopen the app to try again.');
      return;
    }
    setError('');
    setGames(data);
  }, []);
  useLive('discover', ['games', 'game_players'], load);

  const upcoming = useMemo(() => (games ?? []).filter(isUpcoming), [games]);

  const alertGame = upcoming.find((g) => g.one_short && spotsLeft(g) > 0 && !myIds.has(g.id));

  const list = upcoming.filter((g) => {
    if (sport !== 'all' && g.sport !== sport) return false;
    if (day !== 'all' && dayKey(gameStart(g)) !== day) return false;
    const needle = q.trim().toLowerCase();
    if (!needle) return true;
    return [g.title, g.venue, g.suburb, SPORT_LABEL[g.sport], g.level].join(' ').toLowerCase().includes(needle);
  });

  // Put games in the player's home suburb first within each day.
  const home = profile?.suburb?.trim().toLowerCase();
  if (home) {
    list.sort((a, b) => {
      const da = dayKey(gameStart(a));
      const db = dayKey(gameStart(b));
      if (da !== db) return da < db ? -1 : 1;
      const ha = a.suburb.toLowerCase() === home ? 0 : 1;
      const hb = b.suburb.toLowerCase() === home ? 0 : 1;
      return ha - hb || gameStart(a) - gameStart(b);
    });
  }

  async function quickJoin(game) {
    if (!userId) {
      navigate(`/login?next=/game/${game.id}`);
      return;
    }
    const { error: err } = await supabase.from('game_players').insert({ game_id: game.id, user_id: userId });
    if (err) toast(friendlyError(err, 'Couldn’t join. Try again.'));
    else {
      celebrate();
      toast('You’re in. See you on court.');
      navigate(`/game/${game.id}`);
    }
  }

  const days = Array.from({ length: 7 }, (_, i) => {
    const d = new Date();
    d.setDate(d.getDate() + i);
    return { key: dayKey(d), top: i === 0 ? 'TODAY' : dowName(d).toUpperCase(), num: d.getDate() };
  });

  let lastDay = '';

  return (
    <>
      <section className="hello">
        <h1>Find your next game</h1>
        <p className="meta">
          {profile?.suburb
            ? `Pickup games, socials and comps around ${profile.suburb}`
            : 'Pickup games, socials and comps near you'}
        </p>
      </section>

      {error && <p className="notice">{error}</p>}

      {alertGame && (
        <section className="alert" aria-label="Game needs players">
          <div className="row">
            <span className="flag">ONE SHORT</span>
            <span className="sub">{startsLabel(alertGame)}</span>
          </div>
          <h2>
            {SPORT_LABEL[alertGame.sport]}: {alertGame.title} needs {spotsLeft(alertGame)} more
          </h2>
          <p className="sub">
            {[alertGame.venue, alertGame.suburb].join(', ')} · {alertGame.level} · {priceLabel(alertGame)}
          </p>
          <div className="actions">
            <button type="button" className="btn btn-accent btn-wide" onClick={() => quickJoin(alertGame)}>
              I’m in
            </button>
            <Link className="btn btn-line" to={`/game/${alertGame.id}`}>Details</Link>
          </div>
        </section>
      )}

      <div className="search">
        <SearchIcon />
        <label className="sr" htmlFor="q">Search games</label>
        <input
          id="q"
          type="search"
          placeholder="Search games, venues, suburbs"
          autoComplete="off"
          value={q}
          onChange={(e) => setQ(e.target.value)}
        />
      </div>

      <div className="scroller" role="group" aria-label="Sport">
        <button type="button" className="chip" aria-pressed={sport === 'all'} onClick={() => setSport('all')}>
          All sports
        </button>
        {SPORTS.map(([id, label]) => (
          <button key={id} type="button" className="chip" aria-pressed={sport === id} onClick={() => setSport(id)}>
            {label}
          </button>
        ))}
      </div>

      <div className="scroller" role="group" aria-label="Day">
        <button type="button" className="day all" aria-pressed={day === 'all'} onClick={() => setDay('all')}>
          Any day
        </button>
        {days.map((d) => (
          <button key={d.key} type="button" className="day" aria-pressed={day === d.key} onClick={() => setDay(d.key)}>
            <small>{d.top}</small>
            <b>{d.num}</b>
          </button>
        ))}
      </div>

      <div className="list-head">
        <h2>{day === 'all' ? 'Coming up' : fmtDay(new Date(`${day}T00:00`))}</h2>
        <span className="meta">{list.length} {list.length === 1 ? 'game' : 'games'}</span>
      </div>

      {games === null && !error && (
        <div className="list games-grid" aria-label="Loading games">
          {[0, 1, 2, 3].map((i) => <div key={i} className="skeleton" />)}
        </div>
      )}

      {games !== null && list.length === 0 && (
        <div className="empty">
          <strong>No games match</strong>
          <p>Try another sport or day, or post your own game and let people find you.</p>
          <Link className="btn btn-accent" to="/host">Host a game</Link>
        </div>
      )}

      {list.length > 0 && (
        <div className="list games-grid">
          {list.map((g) => {
            const k = dayKey(gameStart(g));
            const showLabel = day === 'all' && k !== lastDay;
            lastDay = k;
            return (
              <Fragment key={g.id}>
                {showLabel && <div className="group-label">{k === todayKey(0) ? 'Today' : fmtDay(gameStart(g))}</div>}
                <GameCard game={g} />
              </Fragment>
            );
          })}
        </div>
      )}
    </>
  );
}
