import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../auth.jsx';
import { supabase } from '../supabase.js';
import { friendlyError } from '../hooks.js';
import { useToast } from '../toast.jsx';
import { celebrate } from '../celebrate.js';
import { DURATIONS, LEVELS, SPORTS } from '../lib/constants.js';
import { todayKey } from '../lib/format.js';

export default function Host() {
  const { userId, profile } = useAuth();
  const navigate = useNavigate();
  const toast = useToast();
  const [form, setForm] = useState(() => ({
    sport: profile?.sports?.[0] ?? 'pickleball',
    level: 'All levels',
    title: '',
    date: todayKey(1),
    time: '18:30',
    duration: '90',
    capacity: '8',
    venue: '',
    suburb: profile?.suburb ?? '',
    price: '0',
    notes: '',
    oneShort: false,
  }));
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  const set = (key) => (e) =>
    setForm((f) => ({ ...f, [key]: e.target.type === 'checkbox' ? e.target.checked : e.target.value }));

  if (!userId) {
    return (
      <>
        <section className="hello">
          <h1>Host a game</h1>
          <p className="meta">Post it, share the invite, and let players fill the spots.</p>
        </section>
        <div className="empty">
          <strong>Sign in to host</strong>
          <p>It takes a few seconds with Google, Apple or your email.</p>
          <Link className="btn btn-accent" to="/login?next=/host">Sign in</Link>
        </div>
      </>
    );
  }

  async function submit(e) {
    e.preventDefault();
    const cap = Math.round(Number(form.capacity));
    const price = Math.round(Number(form.price));
    const startsAt = new Date(`${form.date}T${form.time}`);
    let err = '';
    if (form.title.trim().length < 3) err = 'Give your game a name, like “Social doubles”.';
    else if (!form.date || Number.isNaN(startsAt.getTime())) err = 'Pick a date and start time.';
    else if (startsAt.getTime() < Date.now()) err = 'That time has already passed. Pick a later one.';
    else if (!form.venue.trim()) err = 'Add the venue so players know where to go.';
    else if (!form.suburb.trim()) err = 'Add the suburb.';
    else if (!(cap >= 2 && cap <= 50)) err = 'Players must be between 2 and 50.';
    else if (!(price >= 0 && price <= 500)) err = 'Cost must be between $0 and $500.';
    setError(err);
    if (err) return;

    setBusy(true);
    const { data, error: dbErr } = await supabase
      .from('games')
      .insert({
        host_id: userId,
        sport: form.sport,
        title: form.title.trim(),
        starts_at: startsAt.toISOString(),
        duration_min: Number(form.duration),
        venue: form.venue.trim(),
        suburb: form.suburb.trim(),
        level: form.level,
        price,
        capacity: cap,
        one_short: form.oneShort,
        notes: form.notes.trim(),
      })
      .select('id')
      .single();
    setBusy(false);
    if (dbErr) {
      setError(friendlyError(dbErr, 'Couldn’t post the game. Check your connection and try again.'));
      return;
    }
    celebrate();
    toast('Game posted');
    navigate(`/game/${data.id}`);
  }

  return (
    <>
      <section className="hello">
        <h1>Host a game</h1>
        <p className="meta">Post it, share the invite, and let players fill the spots.</p>
      </section>

      <form className="stack" onSubmit={submit} noValidate>
        <div className="row2">
          <div className="field">
            <label htmlFor="f-sport">Sport</label>
            <select id="f-sport" value={form.sport} onChange={set('sport')}>
              {SPORTS.map(([id, label]) => <option key={id} value={id}>{label}</option>)}
            </select>
          </div>
          <div className="field">
            <label htmlFor="f-level">Level</label>
            <select id="f-level" value={form.level} onChange={set('level')}>
              {LEVELS.map((l) => <option key={l}>{l}</option>)}
            </select>
          </div>
        </div>

        <div className="field">
          <label htmlFor="f-title">Game name</label>
          <input id="f-title" maxLength={80} placeholder="Social doubles round robin" value={form.title} onChange={set('title')} />
        </div>

        <div className="row2">
          <div className="field">
            <label htmlFor="f-date">Date</label>
            <input id="f-date" type="date" min={todayKey(0)} value={form.date} onChange={set('date')} />
          </div>
          <div className="field">
            <label htmlFor="f-time">Start time</label>
            <input id="f-time" type="time" step="900" value={form.time} onChange={set('time')} />
          </div>
        </div>

        <div className="row2">
          <div className="field">
            <label htmlFor="f-duration">Length</label>
            <select id="f-duration" value={form.duration} onChange={set('duration')}>
              {DURATIONS.map(([v, label]) => <option key={v} value={v}>{label}</option>)}
            </select>
          </div>
          <div className="field">
            <label htmlFor="f-capacity">Players (incl. you)</label>
            <input id="f-capacity" type="number" inputMode="numeric" min="2" max="50" value={form.capacity} onChange={set('capacity')} />
          </div>
        </div>

        <div className="row2">
          <div className="field">
            <label htmlFor="f-venue">Venue</label>
            <input id="f-venue" maxLength={80} placeholder="Court, park or centre" value={form.venue} onChange={set('venue')} />
          </div>
          <div className="field">
            <label htmlFor="f-suburb">Suburb</label>
            <input id="f-suburb" maxLength={50} placeholder="Marrickville" value={form.suburb} onChange={set('suburb')} />
          </div>
        </div>

        <div className="field">
          <label htmlFor="f-price">Cost per player (AUD)</label>
          <input id="f-price" type="number" inputMode="numeric" min="0" max="500" value={form.price} onChange={set('price')} />
          <span className="hint">Use 0 for free games. Players pay you at the court for now.</span>
        </div>

        <div className="field">
          <label htmlFor="f-notes">Notes for players</label>
          <textarea id="f-notes" maxLength={600} placeholder="What to bring, parking, who it suits" value={form.notes} onChange={set('notes')} />
        </div>

        <label className="check" htmlFor="f-oneshort">
          <input id="f-oneshort" type="checkbox" checked={form.oneShort} onChange={set('oneShort')} />
          <div>
            <b>Send a One Short alert</b>
            <span>Shows your game at the top of Discover until it fills.</span>
          </div>
        </label>

        {error && <p className="err" role="alert">{error}</p>}

        <button className="btn btn-accent" type="submit" disabled={busy}>
          {busy ? 'Posting…' : 'Post game'}
        </button>
      </form>
    </>
  );
}
