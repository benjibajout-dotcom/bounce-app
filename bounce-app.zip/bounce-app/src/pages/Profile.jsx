import { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../auth.jsx';
import { supabase } from '../supabase.js';
import { useToast } from '../toast.jsx';
import { LEVELS, SPORTS } from '../lib/constants.js';
import Avatar from '../components/Avatar.jsx';

export default function Profile() {
  const { userId, session, profile, reloadProfile } = useAuth();
  const toast = useToast();
  const navigate = useNavigate();
  const [form, setForm] = useState(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (profile && form === null) {
      setForm({
        display_name: profile.display_name ?? '',
        suburb: profile.suburb ?? '',
        level: profile.level ?? 'All levels',
        sports: profile.sports ?? [],
      });
    }
  }, [profile, form]);

  if (!userId) {
    return (
      <>
        <section className="hello"><h1>Your profile</h1></section>
        <div className="empty">
          <strong>Sign in to set up your player profile</strong>
          <p>Pick your sports and suburb so the right games show up first.</p>
          <Link className="btn btn-accent" to="/login?next=/profile">Sign in</Link>
        </div>
      </>
    );
  }

  if (!form) return <p className="meta">Loading your profile…</p>;

  const toggleSport = (id) =>
    setForm((f) => ({ ...f, sports: f.sports.includes(id) ? f.sports.filter((s) => s !== id) : [...f.sports, id] }));

  async function save(e) {
    e.preventDefault();
    if (!form.display_name.trim()) {
      toast('Add your name so players know who’s coming');
      return;
    }
    setBusy(true);
    const { error } = await supabase
      .from('profiles')
      .update({
        display_name: form.display_name.trim().slice(0, 40),
        suburb: form.suburb.trim().slice(0, 50) || null,
        level: form.level,
        sports: form.sports,
      })
      .eq('id', userId);
    setBusy(false);
    if (error) toast('Couldn’t save your profile. Try again.');
    else {
      toast('Profile saved');
      reloadProfile();
    }
  }

  async function signOut() {
    await supabase.auth.signOut();
    navigate('/');
  }

  const provider = session?.user?.app_metadata?.provider;
  const signedInWith = provider === 'google' ? 'Google' : provider === 'apple' ? 'Apple' : 'email';

  return (
    <>
      <section className="profile-head">
        <Avatar id={userId} name={form.display_name} src={profile?.avatar_url} size={64} />
        <div>
          <h1>{form.display_name || 'Your profile'}</h1>
          <p className="meta">Signed in with {signedInWith}</p>
        </div>
      </section>

      <form className="stack" onSubmit={save}>
        <div className="field">
          <label htmlFor="pf-name">Name</label>
          <input id="pf-name" maxLength={40} placeholder="First name and last initial" value={form.display_name}
            onChange={(e) => setForm({ ...form, display_name: e.target.value })} />
          <span className="hint">Shown to other players in games you join.</span>
        </div>
        <div className="field">
          <label htmlFor="pf-suburb">Home suburb</label>
          <input id="pf-suburb" maxLength={50} placeholder="Newtown" value={form.suburb}
            onChange={(e) => setForm({ ...form, suburb: e.target.value })} />
          <span className="hint">Games near you show first.</span>
        </div>
        <div className="field">
          <label htmlFor="pf-level">Usual level</label>
          <select id="pf-level" value={form.level} onChange={(e) => setForm({ ...form, level: e.target.value })}>
            {LEVELS.map((l) => <option key={l}>{l}</option>)}
          </select>
        </div>
        <div className="field">
          <span className="lbl" id="pf-sports-l">Sports you play</span>
          <div className="wrap-chips" role="group" aria-labelledby="pf-sports-l">
            {SPORTS.map(([id, label]) => (
              <button key={id} type="button" className="chip" aria-pressed={form.sports.includes(id)} onClick={() => toggleSport(id)}>
                {label}
              </button>
            ))}
          </div>
        </div>
        <button className="btn btn-brand" type="submit" disabled={busy}>{busy ? 'Saving…' : 'Save profile'}</button>
      </form>

      <button type="button" className="btn btn-line" onClick={signOut}>Sign out</button>
    </>
  );
}
