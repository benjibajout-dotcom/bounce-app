import { useCallback, useEffect, useRef, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { useAuth } from '../auth.jsx';
import { supabase } from '../supabase.js';
import { useLive, friendlyError } from '../hooks.js';
import { useToast } from '../toast.jsx';
import { celebrate } from '../celebrate.js';
import { SPORT_LABEL } from '../lib/constants.js';
import { dayKey, dowName, fmtDay, fmtTime, gameEnd, gameStart, isUpcoming, priceLabel, todayKey } from '../lib/format.js';
import Avatar from '../components/Avatar.jsx';
import { BackIcon, CourtArt, SendIcon, ShareIcon } from '../components/Icons.jsx';

export default function Game() {
  const { id } = useParams();
  const { userId, profile } = useAuth();
  const toast = useToast();
  const navigate = useNavigate();
  const [game, setGame] = useState(undefined); // undefined = loading, null = not found
  const [players, setPlayers] = useState([]);
  const [messages, setMessages] = useState([]);
  const [draft, setDraft] = useState('');
  const [busy, setBusy] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [inviteText, setInviteText] = useState('');
  const msgsRef = useRef(null);

  const load = useCallback(async () => {
    const [g, p] = await Promise.all([
      supabase
        .from('games')
        .select('*, host:profiles!games_host_id_fkey(id, display_name, avatar_url)')
        .eq('id', id)
        .maybeSingle(),
      supabase
        .from('game_players')
        .select('user_id, joined_at, profile:profiles(id, display_name, avatar_url)')
        .eq('game_id', id)
        .order('joined_at'),
    ]);
    setGame(g.data ?? null);
    const list = p.data ?? [];
    setPlayers(list);
    const inGame = !!userId && (list.some((r) => r.user_id === userId) || g.data?.host_id === userId);
    if (inGame) {
      const { data } = await supabase
        .from('messages')
        .select('id, body, created_at, user_id, profile:profiles(id, display_name, avatar_url)')
        .eq('game_id', id)
        .order('created_at', { ascending: false })
        .limit(100);
      setMessages((data ?? []).reverse());
    } else {
      setMessages([]);
    }
  }, [id, userId]);
  useLive(`game-${id}`, ['games', 'game_players', 'messages'], load);

  useEffect(() => {
    const el = msgsRef.current;
    if (el) el.scrollTop = el.scrollHeight;
  }, [messages.length]);

  const back = (
    <Link className="back" to="/">
      <BackIcon />Discover
    </Link>
  );

  if (game === undefined) return <>{back}<p className="meta">Loading game…</p></>;
  if (game === null) {
    return (
      <>
        {back}
        <div className="empty">
          <strong>This game isn’t here anymore</strong>
          <p>The host may have deleted it.</p>
          <Link className="btn btn-accent" to="/">Find another game</Link>
        </div>
      </>
    );
  }

  const start = gameStart(game);
  const end = gameEnd(game);
  const count = players.length;
  const left = Math.max(0, game.capacity - count);
  const isHost = !!userId && game.host_id === userId;
  const mine = !!userId && players.some((p) => p.user_id === userId);
  const past = !isUpcoming(game);
  const hostName = game.host?.display_name || 'A Bounce player';

  async function join() {
    if (!userId) {
      navigate(`/login?next=/game/${id}`);
      return;
    }
    setBusy(true);
    const { error } = await supabase.from('game_players').insert({ game_id: id, user_id: userId });
    setBusy(false);
    if (error) toast(friendlyError(error, 'Couldn’t join. Try again.'));
    else {
      celebrate();
      toast('You’re in. See you on court.');
      load();
    }
  }

  async function leave() {
    setBusy(true);
    const { error } = await supabase.from('game_players').delete().eq('game_id', id).eq('user_id', userId);
    setBusy(false);
    if (error) toast(friendlyError(error, 'Couldn’t leave the game. Try again.'));
    else {
      toast('You’ve left the game');
      load();
    }
  }

  async function toggleOneShort() {
    const next = !game.one_short;
    const { error } = await supabase.from('games').update({ one_short: next }).eq('id', id);
    if (error) toast(friendlyError(error, 'Couldn’t update the alert. Try again.'));
    else {
      toast(next ? 'One Short alert sent' : 'One Short alert off');
      load();
    }
  }

  async function deleteGame() {
    const { error } = await supabase.from('games').delete().eq('id', id);
    if (error) toast(friendlyError(error, 'Couldn’t delete the game. Try again.'));
    else {
      toast('Game deleted');
      navigate('/mine');
    }
  }

  async function share() {
    const url = `${window.location.origin}/game/${id}`;
    const text = `${SPORT_LABEL[game.sport]}: ${game.title}\n${fmtDay(start)} ${fmtTime(start)} at ${game.venue}, ${game.suburb}\n${
      left > 0 ? `${left} ${left === 1 ? 'spot' : 'spots'} left` : 'Full'
    } · ${priceLabel(game)} · ${game.level}`;
    if (navigator.share) {
      try {
        await navigator.share({ title: game.title, text, url });
        return;
      } catch (e) {
        if (e?.name === 'AbortError') return;
      }
    }
    try {
      await navigator.clipboard.writeText(`${text}\n${url}`);
      toast('Invite copied. Paste it in your group chat.');
    } catch {
      setInviteText(`${text}\n${url}`);
    }
  }

  async function send(e) {
    e.preventDefault();
    const body = draft.trim();
    if (!body) return;
    setDraft('');
    const { error } = await supabase.from('messages').insert({ game_id: id, user_id: userId, body: body.slice(0, 500) });
    if (error) {
      setDraft(body);
      toast(friendlyError(error, 'Message didn’t send. Try again.'));
    } else load();
  }

  let cta;
  if (past) cta = <span className="pill">This game has finished</span>;
  else if (isHost) cta = <span className="pill">You’re hosting</span>;
  else if (mine)
    cta = (
      <>
        <span className="pill">You’re in</span>
        <button type="button" className="btn btn-line" onClick={leave} disabled={busy}>Leave game</button>
      </>
    );
  else if (left === 0) cta = <button type="button" className="btn btn-line btn-wide" disabled>Game full</button>;
  else
    cta = (
      <button type="button" className="btn btn-accent btn-wide" onClick={join} disabled={busy}>
        {userId ? `I’m in · ${priceLabel(game)}` : 'Sign in to join'}
      </button>
    );

  return (
    <>
      {back}
      <section className="band">
        <CourtArt />
        <div className="eyebrow">{SPORT_LABEL[game.sport]}</div>
        <h1>{game.title}</h1>
        <div className="facts">
          <div><span>When</span><b>{fmtDay(start)}, {fmtTime(start)}–{fmtTime(end)}</b></div>
          <div><span>Where</span><b>{game.venue}, {game.suburb}</b></div>
          <div><span>Level</span><b>{game.level}</b></div>
          <div><span>Cost</span><b>{game.price > 0 ? `$${game.price} per player` : 'Free'}</b></div>
        </div>
        <div className="hostline">
          <Avatar id={game.host_id} name={hostName} src={game.host?.avatar_url} size={26} />
          <span>Hosted by {isHost ? 'you' : hostName}</span>
        </div>
      </section>

      <div className="meter-row">
        <div className="meter" role="img" aria-label={`${count} of ${game.capacity} spots filled`}>
          <i style={{ width: `${Math.round((100 * Math.min(count, game.capacity)) / game.capacity)}%` }} />
        </div>
        <p className="meta">
          <b>{count} of {game.capacity}</b> going · {left > 0 ? `${left} ${left === 1 ? 'spot' : 'spots'} left` : 'game is full'}
        </p>
      </div>

      <div className="cta">
        {cta}
        <button type="button" className="btn btn-line" onClick={share}>
          <ShareIcon />Invite
        </button>
      </div>

      {inviteText && (
        <div className="field">
          <label htmlFor="invite">Invite text (select and copy)</label>
          <textarea id="invite" className="invite" readOnly value={inviteText} onFocus={(e) => e.target.select()} />
        </div>
      )}

      {isHost && !past && (
        <section className="card" aria-label="Host tools">
          <h2>Host tools</h2>
          <div className="switch-row">
            <div>
              <b>One Short alert</b>
              <p>Puts your game at the top of Discover for nearby players until it fills.</p>
            </div>
            <button
              type="button"
              className="switch"
              role="switch"
              aria-label="One Short alert"
              aria-checked={game.one_short}
              onClick={toggleOneShort}
            >
              <i />
            </button>
          </div>
          {confirmDelete ? (
            <div className="confirm">
              <b>Delete this game for everyone?</b>
              <p className="meta">Players and chat messages go with it. This can’t be undone.</p>
              <div className="actions">
                <button type="button" className="btn btn-danger" onClick={deleteGame}>Delete game</button>
                <button type="button" className="btn btn-line" onClick={() => setConfirmDelete(false)}>Keep game</button>
              </div>
            </div>
          ) : (
            <button type="button" className="btn btn-danger self-start" onClick={() => setConfirmDelete(true)}>
              Delete game
            </button>
          )}
        </section>
      )}

      <section className="stack-sm">
        <h2>Who’s going</h2>
        <div className="people">
          {players.map((p) => {
            const name = p.user_id === userId ? 'You' : p.profile?.display_name || 'Player';
            return (
              <div className="person" key={p.user_id}>
                <Avatar id={p.user_id} name={p.profile?.display_name} src={p.profile?.avatar_url} />
                <span>{name}{p.user_id === game.host_id ? ' (host)' : ''}</span>
              </div>
            );
          })}
          {Array.from({ length: Math.min(left, 4) }, (_, i) => (
            <div className="person" key={`open-${i}`}>
              <span className="seat">Open</span>
              <span aria-hidden="true">&nbsp;</span>
            </div>
          ))}
        </div>
      </section>

      {game.notes && (
        <section className="stack-sm">
          <h2>From the host</h2>
          <p className="notes">{game.notes}</p>
        </section>
      )}

      <section className="chat" aria-label="Game chat">
        <div className="chat-head">
          <h2>Game chat</h2>
          {(mine || isHost) && <span className="meta">{messages.length} {messages.length === 1 ? 'message' : 'messages'}</span>}
        </div>
        {mine || isHost ? (
          <>
            <div className="msgs" ref={msgsRef}>
              {messages.length === 0 && (
                <p className="chat-empty">No messages yet. Say g’day, sort out lifts, or check who’s bringing balls.</p>
              )}
              {messages.map((m) => {
                const me = m.user_id === userId;
                const d = new Date(m.created_at);
                const name = m.profile?.display_name || 'Player';
                return (
                  <div key={m.id} className={me ? 'msg mine' : 'msg'}>
                    {!me && <Avatar id={m.user_id} name={name} src={m.profile?.avatar_url} size={28} />}
                    <div className="bubble">
                      {!me && <span className="who">{name}</span>}
                      <p>{m.body}</p>
                      <span className="at">{dayKey(d) === todayKey(0) ? '' : `${dowName(d)} `}{fmtTime(d)}</span>
                    </div>
                  </div>
                );
              })}
            </div>
            <form className="compose" onSubmit={send}>
              <label className="sr" htmlFor="chat-input">Message</label>
              <input
                id="chat-input"
                maxLength={500}
                autoComplete="off"
                placeholder={profile?.display_name ? 'Message players' : 'Message players (add your name in Profile)'}
                value={draft}
                onChange={(e) => setDraft(e.target.value)}
              />
              <button className="btn btn-accent btn-icon" aria-label="Send message" disabled={!draft.trim()}>
                <SendIcon />
              </button>
            </form>
          </>
        ) : (
          <p className="chat-empty">Join the game to see the chat and talk to the other players.</p>
        )}
      </section>
    </>
  );
}
